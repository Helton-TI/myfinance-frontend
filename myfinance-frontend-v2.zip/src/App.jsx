import React, { useEffect, useMemo, useState } from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import Papa from "papaparse";

const API = import.meta.env.VITE_API_URL || "/api";
const currency = (n) => (n ?? 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const COLORS = ["#6366F1", "#22C55E", "#F59E0B", "#EF4444", "#06B6D4", "#84CC16", "#A855F7", "#14B8A6"];

const CATEGORY_RULES = [
  { key: "moradia", match: ["aluguel", "condom", "boleto", "energia", "água", "luz"] },
  { key: "alimentação", match: ["padaria", "mercado", "supermerc", "acai", "ifood", "restaurante"] },
  { key: "transporte", match: ["posto", "uber", "99", "estacionamento"] },
  { key: "saúde", match: ["clínica", "farmácia", "consulta"] },
  { key: "assinaturas", match: ["spotify", "netflix", "prime", "apple", "openai", "chatgpt"] },
  { key: "lazer", match: ["cinema", "evento", "tickets", "viagem"] },
  { key: "educação", match: ["curso", "escola", "faculdade", "linux"] },
  { key: "pet", match: ["cobasi", "petz"] },
  { key: "diversos", match: [] },
];

function inferCategory(description) {
  const d = (description || "").toLowerCase();
  for (const rule of CATEGORY_RULES) {
    if (rule.match.some((m) => d.includes(m))) return rule.key;
  }
  return "diversos";
}

function Card({ title, value, className = "" }) {
  return (
    <div className={`rounded-2xl shadow-sm border p-4 bg-white ${className}`}>
      <div className="text-sm text-gray-500">{title}</div>
      <div className="text-2xl font-semibold mt-1">{value}</div>
    </div>
  );
}

function Section({ title, children, actions }) {
  return (
    <section className="mt-6">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-lg font-semibold">{title}</h2>
        {actions}
      </div>
      <div className="rounded-2xl border bg-white p-4 shadow-sm">{children}</div>
    </section>
  );
}

function TransactionsTable({ items }) {
  return (
    <div className="overflow-auto">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="text-left text-gray-600">
            <th className="py-2 pr-4">Data</th>
            <th className="py-2 pr-4">Descrição</th>
            <th className="py-2 pr-4">Categoria</th>
            <th className="py-2 pr-4 text-right">Valor</th>
          </tr>
        </thead>
        <tbody>
          {items.map((t, i) => (
            <tr key={i} className="border-t">
              <td className="py-2 pr-4">{t.date?.slice(0,10)}</td>
              <td className="py-2 pr-4">{t.description || t.title}</td>
              <td className="py-2 pr-4 capitalize">{t.category}</td>
              <td className="py-2 pr-0 text-right">{currency(t.amount)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function UploadCSV({ onRows }) {
  const [loading, setLoading] = useState(false);

  function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const rows = results.data
          .map((r) => {
            const date = r.date || r.Data || r.DATA || r["data"];
            const title = r.title || r.description || r.Descrição || r.DESCRICAO;
            const amountStr = r.amount || r.valor || r.Valor;
            const amount = typeof amountStr === "number" ? amountStr : parseFloat(String(amountStr).replace(".", "").replace(",", "."));
            if (!date || !title || isNaN(amount)) return null;
            return { date: String(date).slice(0,10), title: String(title), amount, category: inferCategory(title) };
          })
          .filter(Boolean);
        onRows(rows);
        setLoading(false);
      },
      error: () => setLoading(false),
    });
  }

  return (
    <label className="inline-flex items-center gap-2 px-3 py-2 rounded-xl border shadow-sm cursor-pointer bg-white">
      <input type="file" accept=".csv" className="hidden" onChange={handleFile} />
      <span className="text-sm font-medium">{loading ? "Carregando..." : "Importar CSV (fallback)"} </span>
    </label>
  );
}

export default function App() {
  const [accounts, setAccounts] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [income, setIncome] = useState(0);
  const [connected, setConnected] = useState(false);
  const [demo, setDemo] = useState(false);

  useEffect(() => {
    async function boot() {
      try {
        const a = await fetch(`${API}/accounts`).then(r => r.json());
        setAccounts(Array.isArray(a) ? a : []);
      } catch {}
      try {
        const today = new Date();
        const from = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().slice(0,10);
        const to = new Date(today.getFullYear(), today.getMonth()+1, 0).toISOString().slice(0,10);
        const tx = await fetch(`${API}/transactions?from=${from}&to=${to}`).then(r => r.json());
        setTransactions((Array.isArray(tx) ? tx : []).map((t) => ({
          ...t,
          category: t.category || inferCategory(t.description || t.title),
        })));
      } catch {}
    }
    boot();
  }, []);

  const totals = useMemo(() => {
    const balances = accounts.reduce((s, a) => s + (Number(a.balance) || 0), 0);
    const spent = transactions.reduce((s, t) => s + (t.amount > 0 ? Number(t.amount) : 0), 0);
    const byCat = {};
    for (const t of transactions) {
      const c = t.category || "diversos";
      byCat[c] = (byCat[c] || 0) + (t.amount > 0 ? Number(t.amount) : 0);
    }
    return { balances, spent, byCat };
  }, [accounts, transactions]);

  const chartData = useMemo(() => Object.entries(totals.byCat).map(([name, value]) => ({ name, value })), [totals.byCat]);

  function onImport(rows) {
    setTransactions((prev) => [...rows, ...prev]);
  }

  async function connectBanks() {
    try {
      const res = await fetch(`${API}/link/token`, { method: "POST" });
      const data = await res.json();
      if (data?.linkUrl) window.open(data.linkUrl, "_blank");
      setConnected(true);
    } catch (e) {}
  }

  async function forceSync() {
    try { await fetch(`${API}/sync/start`, { method: "POST" }); } catch {}
    try {
      const a = await fetch(`${API}/accounts`).then(r => r.json());
      setAccounts(Array.isArray(a) ? a : []);
      const today = new Date();
      const from = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().slice(0,10);
      const to = new Date(today.getFullYear(), today.getMonth()+1, 0).toISOString().slice(0,10);
      const tx = await fetch(`${API}/transactions?from=${from}&to=${to}`).then(r => r.json());
      setTransactions((Array.isArray(tx) ? tx : []).map((t) => ({ ...t, category: t.category || inferCategory(t.description || t.title) })));
    } catch {}
  }

  function enableDemo() {
    setDemo(true);
    setAccounts([
      { id: 1, name: "Conta Corrente", type: "checking", balance: 3250.55 },
      { id: 2, name: "Cartão Crédito", type: "credit", balance: -2450.12 },
    ]);
    const sample = [
      { date: new Date().toISOString().slice(0,10), title: "Supermercado Cometa", amount: 57.84 },
      { date: new Date().toISOString().slice(0,10), title: "Posto de Combustível", amount: 120.00 },
      { date: new Date().toISOString().slice(0,10), title: "Netflix", amount: 39.90 },
      { date: new Date().toISOString().slice(0,10), title: "Uber", amount: 22.50 },
    ].map(t => ({
      ...t,
      description: t.title,
      category: inferCategory(t.title)
    }));
    setTransactions(sample);
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="sticky top-0 z-10 backdrop-blur bg-white/80 border-b">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="text-xl font-bold">💰 MyFinance (sync em tempo real)</div>
          <div className="flex items-center gap-3 text-sm">
            <UploadCSV onRows={onImport} />
            <button className="px-3 py-2 rounded-xl border bg-white shadow-sm" onClick={connectBanks}>
              {connected ? "Gerenciar conexões" : "Conectar Bancos (API)"}
            </button>
            <button className="px-3 py-2 rounded-xl border bg-white shadow-sm" onClick={forceSync}>Sincronizar agora</button>
            <button className="px-3 py-2 rounded-xl border bg-white shadow-sm" onClick={enableDemo}>{demo ? "Demo ativa" : "Ativar modo demo"}</button>
          </div>
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-4 pb-16">
        <div className="grid md:grid-cols-3 gap-4 mt-6">
          <Card title="Saldos agregados" value={currency(totals.balances)} />
          <Card title="Gastos do mês" value={currency(totals.spent)} />
          <Card title="Renda (opcional p/ metas)" value={currency(income)} />
        </div>

        <Section title="Metas (opcional)">
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm text-gray-600">Renda mensal (para metas)</label>
              <input type="number" className="mt-1 w-full border rounded-xl px-3 py-2" value={income} onChange={(e)=>setIncome(Number(e.target.value)||0)} />
            </div>
            <p className="text-sm text-gray-500 md:col-span-2">A renda não é usada na sincronização. Ela serve apenas para comparar metas e capacidade de gasto.</p>
          </div>
        </Section>

        <Section title="Gastos por categoria (mês)">
          {chartData.length ? (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie dataKey="value" data={chartData} outerRadius={100} label>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v) => currency(v)} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="text-sm text-gray-500">Sem transações ainda. Conecte um banco, importe CSV ou ative o modo demo.</div>
          )}
        </Section>

        <Section title="Transações do mês">
          <TransactionsTable items={transactions} />
        </Section>
      </main>
    </div>
  );
}
